package com.example.football.models.entity;

public enum PositionEnum {
    ATT, MID, DEF

}
