package com.example.football.util;

public interface ValidationUtils {

    <T> boolean isValid(T entity);
}
