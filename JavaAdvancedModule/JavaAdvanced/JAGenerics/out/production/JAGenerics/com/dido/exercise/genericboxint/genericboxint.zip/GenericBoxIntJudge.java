
public class GenericBoxIntJudge {


    static class Box<T> {

        private T value;

        public Box(){

        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value.getClass().getTypeName() + ": "+value;
        }
    }
}
