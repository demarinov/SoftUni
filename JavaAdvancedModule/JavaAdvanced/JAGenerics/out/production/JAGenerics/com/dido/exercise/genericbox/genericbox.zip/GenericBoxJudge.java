

import java.util.Scanner;

public class GenericBoxJudge<T> {



        private T value;

        public GenericBoxJudge(){

        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value.getClass().getTypeName() + ": "+value;
        }
}
