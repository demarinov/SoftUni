package com.dido.exercise.tuple;

public class Tuple<T,P> {

    private T itemOne;
    private P itemTwo;



    public Tuple(T item1, P item2) {
        this.itemOne = item1;
        this.itemTwo = item2;
    }


    public T getItemOne() {
        return itemOne;
    }

    public void setItemOne(T itemOne) {
        this.itemOne = itemOne;
    }

    public P getItemTwo() {
        return itemTwo;
    }

    public void setItemTwo(P itemTwo) {
        this.itemTwo = itemTwo;
    }

    @Override
    public String toString() {
        return itemOne + " -> " + itemTwo;
    }
}
