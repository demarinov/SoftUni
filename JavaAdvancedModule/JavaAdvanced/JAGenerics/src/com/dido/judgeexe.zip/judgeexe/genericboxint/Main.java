package com.dido.exercise.genericboxint;

import java.util.Scanner;

public class Main {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        int n = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < n; i++) {
            Integer input = Integer.parseInt(sc.nextLine());
            GenericBoxIntJudge.Box<Integer> box = new GenericBoxIntJudge.Box<>();
            box.setValue(input);

            System.out.println(box);
        }

    }
}
