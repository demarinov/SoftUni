package com.dido.exercise.genericbox;

import java.util.Scanner;

public class Main {
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        int n = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < n; i++) {
            String input = sc.nextLine();
            GenericBoxJudge<String> box = new GenericBoxJudge<>();
            box.setValue(input);

            System.out.println(box);
        }

    }
}
