package com.dido.exercise.genericswapstring;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class GenericSwapJudge {

    public static <T> void swap(List<T> elements, int idxOne, int idxTwo) {

        if (idxOne < 0 || idxOne >= elements.size()
                || idxTwo < 0 || idxTwo>=elements.size()) {
            return;
        }

        T element = elements.get(idxOne);
        elements.set(idxOne, elements.get(idxTwo));
        elements.set(idxTwo, element);


    }
}
