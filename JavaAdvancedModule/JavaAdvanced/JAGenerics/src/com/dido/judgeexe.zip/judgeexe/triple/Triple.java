package com.dido.exercise.triple;


public class Triple<T,P,F> {



    private T itemOne;
    private P itemTwo;
    private F itemThree;

    public Triple(T itemOne, P itemTwo, F itemThree) {
        this.itemOne = itemOne;
        this.itemTwo = itemTwo;
        this.itemThree = itemThree;
    }

    public T getItemOne() {
        return itemOne;
    }

    public void setItemOne(T itemOne) {
        this.itemOne = itemOne;
    }

    public P getItemTwo() {
        return itemTwo;
    }

    public void setItemTwo(P itemTwo) {
        this.itemTwo = itemTwo;
    }

    public F getItemThree() {
        return itemThree;
    }

    public void setItemThree(F itemThree) {
        this.itemThree = itemThree;
    }

    @Override
    public String toString() {

        return String.format("%s -> %s -> %s",itemOne, itemTwo, itemThree);
    }
}
