package com.dido.exercise.genericbox;

import java.util.Scanner;

public class GenericBox<T> {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < n; i++) {
            String input = sc.nextLine();
            GenericBox<String> box = new GenericBox<>();
            box.setValue(input);

            System.out.println(box);
        }

    }

        private T value;

        public GenericBox(){

        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value.getClass().getTypeName() + ": "+value;
        }
}
