import java.util.Scanner;


public class Main {

    private static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {


            String[] personData = sc.nextLine().split("\\s");
            String name = personData[0] + " "+personData[1];
            String address = personData[2];
            TupleJudge<String, String> tuple = new TupleJudge<>(name, address);

            personData = sc.nextLine().split("\\s");

            name = personData[0];
            Integer beerAmount = Integer.parseInt(personData[1]);
            TupleJudge<String, Integer> tuple2 = new TupleJudge<>(name, beerAmount);

            String[] numbers = sc.nextLine().split("\\s");

            Integer num1 = Integer.parseInt(numbers[0]);
            Double num2 = Double.parseDouble(numbers[1]);

            TupleJudge<Integer, Double> tuple3 = new TupleJudge<>(num1, num2);

            System.out.println(tuple);
            System.out.println(tuple2);
            System.out.println(tuple3);

        }
}
