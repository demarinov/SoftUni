package com.dido.lab.judge.jar;

public class Main {

    public static void main(String[] args) {

        Jar<Jar.Pickle> jars = new Jar();

        jars.add(new Jar.Pickle());
        jars.add(new Jar.Pickle());

        Jar.Pickle pickle = jars.remove();
    }


}
