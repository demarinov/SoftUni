package com.dido.lab.judge.genericscale;


public class Main {

    public static void main(String[] args) {

        GenericScale.Scale<String> stringScale = new GenericScale.Scale<>("a","c");
        System.out.println(stringScale.getHeavier());

        GenericScale.Scale<Integer> intScale = new GenericScale.Scale<>(1,2);
        System.out.println(intScale.getHeavier());
    }


}
