package com.dido.lab.judge.arraycreator;


public class Main {

    public static void main(String[] args) {

        String[] strings = ArrayCreator.create(10,"none");
        Integer[] ints = ArrayCreator.create(Integer.class,10,0);

//        Arrays.stream(strings).forEach(System.out::println);
//        Arrays.stream(ints).forEach(System.out::println);
    }
}
