package com.dido.lab.judge.arraycreator;

import java.lang.reflect.Array;
import java.util.Arrays;
// should go to source when submitted in judge ...
public class ArrayCreator {

    public static <T> T[] create(int len, T item) {

        T[] array = (T[]) new Object[len];

        for (int i = 0; i < array.length; i++) {
            array[i] = item;
        }

        return array;
    }

    public static <T> T[] create(Class<T> classs,int len, T item) {

        T[] array = (T[]) Array.newInstance(classs,len);

        for (int i = 0; i < array.length; i++) {

            array[i]=item;
        }

        return array;
    }
}
