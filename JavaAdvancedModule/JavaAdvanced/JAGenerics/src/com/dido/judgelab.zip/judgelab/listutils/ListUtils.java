package com.dido.lab.judge.listutils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ListUtils {


    public static <T extends Comparable<T>> T getMax(List<T> list) {

        if (list.isEmpty()) {
            throw new IllegalArgumentException("Empty list!");
        }

        return list.stream().sorted(Comparator.reverseOrder()).limit(1).findFirst().orElse(null);
    }

    public static <T extends Comparable<T>> T getMin(List<T> list) {


        if (list.isEmpty()) {
            throw new IllegalArgumentException("Empty list!");
        }

        return list.stream().sorted().limit(1).findFirst().orElse(null);
    }
}
