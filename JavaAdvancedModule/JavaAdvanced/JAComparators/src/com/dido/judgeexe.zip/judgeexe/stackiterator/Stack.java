
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Stack implements Iterable<Integer> {

    private List<Integer> dataList;
    private Iterator customIterator;

    public Stack() {

        dataList = new ArrayList<>();
    }

    public List<Integer> getDataList() {
        return dataList;
    }

    public void setDataList(List<Integer> dataList) {
        this.dataList = dataList;
    }

    public Iterator getCustomIterator() {
        return customIterator;
    }

    public void setCustomIterator(Iterator customIterator) {
        this.customIterator = customIterator;
    }

    public void push(Integer element) {
        dataList.add(element);
    }

    public Integer pop() {
        if (!dataList.isEmpty()) {
            return dataList.remove(dataList.size() - 1);
        }

        return null;
    }

    @Override
    public Iterator<Integer> iterator() {
        return new CustomIterator();
    }

    private final class CustomIterator implements Iterator<Integer> {

        private Integer index = dataList.size()-1;

        @Override
        public boolean hasNext() {
            if (index >= 0) {
                return true;
            }

            return false;
        }

        @Override
        public Integer next() {
            Integer element = dataList.get(index--);
            return element;
        }

        public Integer getIndex() {
            return index;
        }

        private void setIndex(Integer index) {
            this.index = index;
        }
    }
}
