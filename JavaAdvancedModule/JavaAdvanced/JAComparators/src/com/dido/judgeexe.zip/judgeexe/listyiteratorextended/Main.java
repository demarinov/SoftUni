
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {

    private static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {

        String input = sc.nextLine();

        ListyIterator iteratorCollection = null;

        while(!"END".equals(input)) {
            String[] data = input.split("\\s+");

            String command = data[0];
            switch (command) {

                case "Create":

                    String[] elements = new String[data.length - 1];

                    for (int i = 1; i < data.length; i++) {
                        elements[i - 1] = data[i];
                    }

                    iteratorCollection = create(elements);
                    break;
                case "Move":
                    System.out.println(iteratorCollection.move());
                    break;
                case "Print":
                    try {
                        iteratorCollection.print();
                    } catch (NoSuchElementException e) {
                        System.out.println(e.getLocalizedMessage());
                    }
                    break;
                case "HasNext":
                    System.out.println(iteratorCollection.hasNext());
                    break;
                case "PrintAll":
                    iteratorCollection.printAll();
                    break;
                default:
                    break;
            }


            input = sc.nextLine();
        }

    }

    public static ListyIterator create(String... data) {

        ListyIterator iteratorCollection = new ListyIterator(data);
        iteratorCollection.customIterator = iteratorCollection.iterator();

        return iteratorCollection;
    }

}
