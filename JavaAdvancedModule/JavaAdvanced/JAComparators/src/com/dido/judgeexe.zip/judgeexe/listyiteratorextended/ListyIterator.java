

import java.util.*;

public class ListyIterator implements Iterable<String> {

    List<String> dataList;
    Iterator customIterator;

    public ListyIterator(String ... data) {

        if (data.length == 0) {
            this.dataList = new ArrayList<>();
        } else {
            this.dataList = new ArrayList<>(Arrays.asList(data));
        }
    }

    public void printAll() {

        for (String element : this) {
            System.out.print(element+" ");
        }

        System.out.println();
    }

    public void print() {

        if (dataList.isEmpty()) {
            throw new NoSuchElementException("Invalid Operation!");
        }

        System.out.println(dataList.get(((CustomIterator)this.customIterator).getIndex()));
    }

    public boolean move() {

        if (hasNext()) {
            this.customIterator.next();
            return true;
        }

        return false;
    }

    public boolean hasNext() {

        if (((CustomIterator)this.customIterator).getIndex() == dataList.size()-1) {
            return false;
        }
        return this.customIterator.hasNext();
    }

    @Override
    public Iterator<String> iterator() {
        return new CustomIterator();
    }

    private final class CustomIterator implements Iterator<String> {

        Integer index = 0;

        @Override
        public boolean hasNext() {
            if (index <= dataList.size()-1) {
                return true;
            }

            return false;
        }

        @Override
        public String next() {
            String element = dataList.get(index);
            index++;
            return element;
        }

        public Integer getIndex() {
            return index;
        }

        private void setIndex(Integer index) {
            this.index = index;
        }
    }
}
