
import java.util.*;

public class ListyIterator {

    List<String> dataList;
    Integer index;



    public ListyIterator(String ... data) {

        if (data.length == 0) {
            this.dataList = new ArrayList<>();
        } else {
            this.dataList = new ArrayList<>(Arrays.asList(data));
        }

        index = 0;
    }


    public void print() {

        if (dataList.isEmpty()) {
            throw new NoSuchElementException("Invalid Operation!");
        }

        System.out.println(dataList.get(index));
    }

    public boolean move() {

        if (hasNext()) {
            index++;
            return true;
        }

        return false;
    }

    public boolean hasNext() {
        if (index < dataList.size()-1) {
            return true;
        }

        return false;
    }

    public String next() {
        return dataList.iterator().next();
    }
}
