
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String input  = sc.nextLine();

        Stack stackIteratorCollection = new Stack();
        while(!"END".equals(input)) {

            String[] commandData = input.split("\\s+");

            switch(commandData[0]) {

                case "Push":


                    for (int i = 1; i < commandData.length; i++) {
                        Integer element = Integer.parseInt(commandData[i].replaceAll(",",""));
                        stackIteratorCollection.push(element);
                    }


                    break;
                case "Pop":
                    Integer element = stackIteratorCollection.pop();

                    if (element == null) {

                        System.out.println("No elements");
                        break;
                    }

                    break;
            }

            input = sc.nextLine();
        }

        for (int i = 0; i < 2; i++) {
            for (Integer element : stackIteratorCollection) {

                System.out.println(element);
            }
        }

    }
}
