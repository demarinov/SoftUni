
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        String input = sc.nextLine();

        ListyIterator iterator = null;

        while(!"END".equals(input)) {
            String[] data = input.split("\\s+");

            String command = data[0];
            switch (command) {

                case "Create":

                    String[] elements = new String[data.length - 1];

                    for (int i = 1; i < data.length; i++) {
                        elements[i - 1] = data[i];
                    }

                    iterator = create(elements);
                    break;
                case "Move":
                    System.out.println(iterator.move());
                    break;
                case "Print":
                    try {
                        iterator.print();
                    } catch (NoSuchElementException e) {
                        System.out.println(e.getLocalizedMessage());
                    }
                    break;
                case "HasNext":
                    System.out.println(iterator.hasNext());
                    break;
                default:
                    break;
            }


            input = sc.nextLine();
        }

    }


    public static ListyIterator create(String... data) {

        ListyIterator iterator = new ListyIterator(data);

        return iterator;
    }
}
