package glacialExpedition.models.explorers;

import glacialExpedition.models.suitcases.Suitcase;

public abstract class BaseExplorer implements Explorer {

    private String name;
    private double energy;
    private Suitcase suitcase;

    protected BaseExplorer(String name, double energy) {
        setName(name);
        setEnergy(energy);
    }

    public void search() {

        this.energy -= 15;
        if (this.energy < 0) {
            this.energy = 0;
        }
    }

    public boolean canSearch() {

        return energy > 0 ? true : false;
    }

    @Override
    public String getName() {
        return name;
    }

    protected void setName(String name) {

        if (name == null || name.isBlank()) {

            throw new NullPointerException("Explorer name cannot be null or empty.");
        }
        this.name = name;
    }

    @Override
    public double getEnergy() {
        return energy;
    }

    protected void setEnergy(double energy) {
        if (energy < 0) {

            throw new IllegalArgumentException("Cannot create Explorer with negative energy.");
        }
        this.energy = energy;
    }

    @Override
    public Suitcase getSuitcase() {
        return suitcase;
    }

    protected void setSuitcase(Suitcase suitcase) {
        this.suitcase = suitcase;
    }
}
